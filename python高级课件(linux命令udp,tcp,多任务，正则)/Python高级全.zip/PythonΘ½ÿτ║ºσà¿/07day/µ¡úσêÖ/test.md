```py
self.window.blit(self.map.bg_img1, (0, self.map.bg_img1_y))
        self.window.blit(self.map.bg_img2, (0, self.map.bg_img2_y))
```



